var deptNumber = execution.getVariable("deptNumber");
var workplaceCount = execution.getVariable("workplaceCount");
var message = "Отдел " + deptNumber + ": " + workplaceCount + " техники.";

var URL = 'https://telegram-api.iss-reshetnev.ru:8000/send_message'
var requestBody = "login=SilchenkoDM&text=" + encodeURIComponent(message);

var response = connector.get("http-connector").createRequest()
  .method("GET")
  .url(URL + "?" + requestBody)
  .execute();
